import{c as r,s as e}from"./flowDiagram-T62WH6J4-BOgxbvEG.js";import{_ as a}from"./mermaid.core-DqO9MXB3.js";import"./chunk-5VM5RSS4-BBx8x1x1.js";import"./chunk-XXDRQBXY-D-5uZtyv.js";import"./chunk-POPQ4Y6H-CXwshHV3.js";import"./chunk-F27PBJKO-EzMVAn80.js";import"./app-FUkVWT2f.js";import"./index-D6FUvVB1.js";import"./channel-DLHA98n1.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};
